# pySearchErr
Detects Python3 exception and searches for the error on Google automatically

## 0.2.0 Release Notes
* Display the full error trace in the console

## Installation
```
pip install pySearchErr
```
## Usage
```
pySearchErr <filename.py>
```