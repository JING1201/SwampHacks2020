# pySearchErr
Detects Python3 exception and searches for the error on Google automatically
## Installation
```
pip install pySearchErr
```
## Usage
```
pySearchErr <filename.py>
```